package main;

import processing.core.PApplet;
import processing.serial.Serial;

public class Main extends PApplet {

	public static void main(String[] args) {
		PApplet.main("main.Main");

	}

	Serial serial;

	public void settings() {
		size(500, 500);

	}

	public void setup() {
		String[] puertos = Serial.list();
		printArray(puertos);
	//	serial = new Serial(this, puertos[0], 9600);
		//serial.bufferUntil('\n');
	}

	public void draw() {
		background(0);

	}

	public void serialEvent(Serial serial) {
		String mensajeRecibido = serial.readStringUntil('\n');

	}

	public void mousePressed() {

	}

	public void mouseDragged() {

	}

}
