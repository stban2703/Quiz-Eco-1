package view;

import processing.core.PApplet;

public class LoginScreen {
	private Input [] arrayInputs;

	public LoginScreen(PApplet p) {
		arrayInputs = new Input[2];
		int incrementPosY = 0;
		for (int i = 0; i < arrayInputs.length; i++) {
			arrayInputs[i]  = new Input(p, 200, 250+incrementPosY);
			incrementPosY+=50;
		}
	}

	public void paint() {
		for (int i = 0; i < arrayInputs.length; i++) {
			arrayInputs[i].paint();
		}
	}

	public void focusInputs(float mouseX, float mouseY) {
		for (int i = 0; i < arrayInputs.length; i++) {
			if (mouseX >= arrayInputs[i].getPosX() && mouseX <= arrayInputs[i].getPosX() + 200
					&& mouseY >= arrayInputs[i].getPosY() && mouseY <= arrayInputs[i].getPosY() + 30) {
				arrayInputs[i].setFocus(true);
			} else {
				arrayInputs[i].setFocus(false);
			}
		}
	}

	public void writeTextInput(char key) {
		for (int i = 0; i < arrayInputs.length; i++) {
			if (arrayInputs[i].isFocus() && arrayInputs[i].getText().length()<15) {
				arrayInputs[i].setText(arrayInputs[i].getText() + key);
			}
		}
	}

	public void eraseTextInput() {
		
		for (int i = 0; i < arrayInputs.length; i++) {
			if (arrayInputs[i].isFocus() && arrayInputs[i].getText().length()-1>=0) {
				int indice = arrayInputs[i].getText().length() - 1;
				arrayInputs[i].setText(arrayInputs[i].getText().substring(0, indice));
			}
		}
		
	}
}
