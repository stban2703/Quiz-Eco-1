package model;

public class User {
	public User() {
		
	}
	
	public boolean login(String userName) {
		if(userName.equals("pipegarcial159")) {
			return true;
		}
		return false;
	}
}
